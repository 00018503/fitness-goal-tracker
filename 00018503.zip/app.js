const express = require("express");
const mongoose = require("mongoose");
const methodOverride = require("method-override");
const { body, validationResult } = require("express-validator");
const path = require("path");
const Goal = require("./models/goal");
const goalsRouter = require("./routes/goals");

const app = express();

// Connect to MongoDB (use local for dev, env var for deployment)
mongoose.connect(
  process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/fitness-goals",
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  }
);

// Middleware
app.use(express.urlencoded({ extended: false }));
app.use(methodOverride("_method"));
app.use(express.static(path.join(__dirname, "public")));
app.set("view engine", "pug");

// Routes
app.use("/goals", goalsRouter);

// Homepage redirects to goals list
app.get("/", (req, res) => {
  res.redirect("/goals");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
